# Comet-Updating-System

Designed by: N4ri

Resources used:

- Spinning RGB: Joe22
- Animation Code: Serenity by Laxion (Who knows where he got it from)
- Directory Code (Mostly): ImmuneLion318
- Registry Settings Code: https://www.c-sharpcorner.com/UploadFile/f9f215/windows-registry/
- Exclusion Code, Opening Comet Code, that weird HttpGet function, CometAuth: Showerhead
- Extraction Code: https://learn.microsoft.com/en-us/dotnet/api/system.io.compression.zipfile.extracttodirectory?view=net-7.0
- DownloadFile Code: https://www.youtube.com/watch?v=AzwLQKWY8ZM
- ProgressBar Code: MCGamin1738
